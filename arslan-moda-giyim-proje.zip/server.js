require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const PRODUCTS_FILE = path.join(DATA_DIR, "products.json");
const ADMIN_FILE = path.join(DATA_DIR, "admin.json");

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(PRODUCTS_FILE)) fs.writeFileSync(PRODUCTS_FILE, "[]");
if (!fs.existsSync(ADMIN_FILE)) {
  const password = process.env.ADMIN_PASSWORD;
  if (!password) {
    console.warn("ADMIN_PASSWORD ayarlanmamış. Admin hesabını kurmak için README.md dosyasını takip edin.");
  } else {
    fs.writeFileSync(ADMIN_FILE, JSON.stringify({
      username: process.env.ADMIN_USERNAME || "arslanmoda42",
      passwordHash: bcrypt.hashSync(password, 12)
    }, null, 2));
  }
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  name: "arslanmoda.sid",
  secret: process.env.SESSION_SECRET || "development-only-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 8
  }
}));

const readProducts = () => JSON.parse(fs.readFileSync(PRODUCTS_FILE, "utf8"));
const writeProducts = (items) => fs.writeFileSync(PRODUCTS_FILE, JSON.stringify(items, null, 2));
const adminAuth = (req, res, next) => {
  if (req.session && req.session.isAdmin) return next();
  return res.status(401).json({ error: "Yönetici girişi gerekli." });
};

app.use(express.static(path.join(__dirname, "public")));

app.get("/api/config", (_req, res) => {
  res.json({ whatsappPhone: (process.env.WHATSAPP_PHONE || "905433134576").replace(/\D/g, "") });
});
app.get("/api/products", (_req, res) => res.json(readProducts()));

app.post("/api/admin/login", (req, res) => {
  const data = fs.existsSync(ADMIN_FILE) ? JSON.parse(fs.readFileSync(ADMIN_FILE, "utf8")) : null;
  if (!data) return res.status(503).json({ error: "Yönetici henüz kurulmadı. README.md dosyasını takip edin." });
  const { username, password } = req.body || {};
  if (username !== data.username || !bcrypt.compareSync(password || "", data.passwordHash)) {
    return res.status(401).json({ error: "Kullanıcı adı veya şifre hatalı." });
  }
  req.session.isAdmin = true;
  req.session.username = data.username;
  res.json({ ok: true, username: data.username });
});
app.post("/api/admin/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});
app.get("/api/admin/session", (req, res) => {
  res.json({ authenticated: !!(req.session && req.session.isAdmin), username: req.session?.username || null });
});

app.post("/api/admin/products", adminAuth, (req, res) => {
  const { name, category, price, description = "", image = "", sizes = "S, M, L, XL", colors = "Siyah, Beyaz, Gri", stock = 0 } = req.body || {};
  if (!name || !category || !Number.isFinite(Number(price)) || Number(price) < 0) {
    return res.status(400).json({ error: "Ürün adı, kategori ve geçerli fiyat zorunludur." });
  }
  const products = readProducts();
  const product = {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    name: String(name).trim(),
    category: String(category).trim(),
    price: Number(price),
    description: String(description).trim(),
    image: String(image).trim(),
    sizes: String(sizes).split(",").map(x => x.trim()).filter(Boolean),
    colors: String(colors).split(",").map(x => x.trim()).filter(Boolean),
    stock: Math.max(0, Number.parseInt(stock, 10) || 0),
    createdAt: new Date().toISOString()
  };
  products.unshift(product);
  writeProducts(products);
  res.status(201).json(product);
});
app.put("/api/admin/products/:id", adminAuth, (req, res) => {
  const products = readProducts();
  const index = products.findIndex(p => p.id === req.params.id);
  if (index < 0) return res.status(404).json({ error: "Ürün bulunamadı." });
  const old = products[index];
  const b = req.body || {};
  products[index] = {
    ...old,
    name: b.name === undefined ? old.name : String(b.name).trim(),
    category: b.category === undefined ? old.category : String(b.category).trim(),
    price: b.price === undefined ? old.price : Number(b.price),
    description: b.description === undefined ? old.description : String(b.description).trim(),
    image: b.image === undefined ? old.image : String(b.image).trim(),
    sizes: b.sizes === undefined ? old.sizes : String(b.sizes).split(",").map(x => x.trim()).filter(Boolean),
    colors: b.colors === undefined ? old.colors : String(b.colors).split(",").map(x => x.trim()).filter(Boolean),
    stock: b.stock === undefined ? old.stock : Math.max(0, Number.parseInt(b.stock, 10) || 0)
  };
  writeProducts(products);
  res.json(products[index]);
});
app.delete("/api/admin/products/:id", adminAuth, (req, res) => {
  const products = readProducts();
  const next = products.filter(p => p.id !== req.params.id);
  if (next.length === products.length) return res.status(404).json({ error: "Ürün bulunamadı." });
  writeProducts(next);
  res.json({ ok: true });
});

app.get("/admin", (_req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return res.status(404).json({ error: "Bulunamadı." });
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => console.log(`Arslan Moda Giyim çalışıyor: http://localhost:${PORT}`));
