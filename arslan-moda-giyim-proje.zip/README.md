# Arslan Moda Giyim — bağımsız mağaza başlangıç projesi

Bu proje Wix veya başka bir mağaza oluşturucusuna bağlı değildir. Node.js + Express ile hazırlanmış özel yazılım başlangıcıdır.

## İçerik
- Müşteri mağazası: `/`
- Yönetim paneli: `/admin`
- Yönetici kullanıcı adı varsayılanı: `arslanmoda42`
- Ürün ekleme, fiyat düzenleme, stok, kategori, beden, renk ve görsel URL'si
- WhatsApp sipariş bağlantısı; ödeme ve banka bilgileri WhatsApp üzerinden paylaşılır
- Siyah, beyaz ve gri tasarım

## Yerel çalıştırma
1. Node.js 20 veya üzerini kur.
2. Bu klasörde `.env.example` dosyasını `.env` olarak kopyala.
3. `.env` içindeki `ADMIN_PASSWORD` alanına benzersiz ve güçlü bir şifre yaz. En az 12 karakter önerilir.
4. `SESSION_SECRET` değerini uzun ve rastgele bir değerle değiştir.
5. Terminalde çalıştır:
   ```bash
   npm install
   npm run setup-admin
   npm start
   ```
6. Tarayıcıda `http://localhost:3000` adresini aç. Yönetim paneli `http://localhost:3000/admin`.

## Önemli yayınlama notları
Bu klasör henüz internete yayınlanmış değildir. Canlıya almak için Node.js destekli bir sunucu gerekir. Ücretsiz barındırma sağlayıcılarının disk kalıcılığı ve uyku/limit politikaları değişebilir. `data/products.json` dosyası yerel JSON saklama kullanır; gerçek satışta kalıcı diskli barındırma veya veritabanı (ör. PostgreSQL) tercih edilmeli, düzenli yedek alınmalıdır.

WhatsApp numarası `.env` içindeki `WHATSAPP_PHONE` ile değiştirilir; uluslararası formatta, başında `+` olmadan yazılır. Örnek: `905433134576`.

## Şu an henüz dahil olmayanlar
- Gerçek dosya yükleme (ürün görseli için şimdilik herkese açık görsel URL'si girilir)
- Otomatik kargo entegrasyonu
- Otomatik ödeme doğrulaması
- Siparişlerin kalıcı yönetim ekranı / veritabanı
- Canlı alan adı ve HTTPS yapılandırması

Ürün ve fiyatlar örnek/başlangıç amaçlıdır; mağaza yayına alınmadan önce gerçek ürünlerle doldurulmalıdır.


## Render üzerinden yayınlama (bağımsız barındırma)
Bu proje Render'a dağıtım için `render.yaml` dosyası içerir. Yayına almak için:
1. Projeyi kendi GitHub hesabına yükle.
2. Render hesabında yeni Blueprint/Web Service oluşturup bu depoyu bağla.
3. `ADMIN_PASSWORD` ortam değişkenini güçlü, benzersiz bir şifreyle doldur.
4. Deploy tamamlanınca verilen `onrender.com` adresini açıp `/admin` sayfasından giriş yap.
5. Kendi alan adın `arslanmodagiyim.com` için alan adı sağlayıcının DNS ayarlarını Render'ın verdiği hedeflere göre yapılandır.

**Veri saklama uyarısı:** Bu başlangıç sürümü ürünleri `data/products.json` dosyasında tutar. Ücretsiz web servislerinde dosya sistemi kalıcı olmayabilir ve yeniden dağıtımda ürün kayıtları silinebilir. Gerçek ürünleri girmeden önce kalıcı disk veya PostgreSQL gibi kalıcı bir veritabanı bağlanmalı. Bu dosya şimdilik demo/kurulum başlangıcıdır; canlı satış öncesi veri kalıcılığı, fotoğraf yükleme, HTTPS/alan adı, gizlilik/mesafeli satış ve yedekleme kontrol edilmelidir.
