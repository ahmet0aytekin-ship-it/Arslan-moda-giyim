# Arslan Moda Giyim — bağımsız mağaza başlangıç projesi

Bu proje Wix veya başka bir mağaza oluşturucusuna bağlı değildir. Node.js + Express ile hazırlanmış özel yazılım başlangıcıdır.

## İçerik
- Müşteri mağazası: `/`
- Yönetim paneli: `/admin`
- Yönetici kullanıcı adı varsayılanı: `arslanmoda42`
- Ürün ekleme, fiyat düzenleme, stok, kategori, beden, renk ve görsel URL'si
- WhatsApp sipariş bağlantısı; ödeme ve banka bilgileri WhatsApp üzerinden paylaşılır
- Siyah, beyaz ve gri tasarım

## Yerel çalıştırma
1. Node.js 20 veya üzerini kur.
2. Bu klasörde `.env.example` dosyasını `.env` olarak kopyala.
3. `.env` içindeki `ADMIN_PASSWORD` alanına benzersiz ve güçlü bir şifre yaz. En az 12 karakter önerilir.
4. `SESSION_SECRET` değerini uzun ve rastgele bir değerle değiştir.
5. Terminalde çalıştır:
   ```bash
   npm install
   npm run setup-admin
   npm start
   ```
6. Tarayıcıda `http://localhost:3000` adresini aç. Yönetim paneli `http://localhost:3000/admin`.

## Önemli yayınlama notları
Bu klasör henüz internete yayınlanmış değildir. Canlıya almak için Node.js destekli bir sunucu gerekir. Ücretsiz barındırma sağlayıcılarının disk kalıcılığı ve uyku/limit politikaları değişebilir. `data/products.json` dosyası yerel JSON saklama kullanır; gerçek satışta kalıcı diskli barındırma veya veritabanı (ör. PostgreSQL) tercih edilmeli, düzenli yedek alınmalıdır.

WhatsApp numarası `.env` içindeki `WHATSAPP_PHONE` ile değiştirilir; uluslararası formatta, başında `+` olmadan yazılır. Örnek: `905433134576`.

## Şu an henüz dahil olmayanlar
- Gerçek dosya yükleme (ürün görseli için şimdilik herkese açık görsel URL'si girilir)
- Otomatik kargo entegrasyonu
- Otomatik ödeme doğrulaması
- Siparişlerin kalıcı yönetim ekranı / veritabanı
- Canlı alan adı ve HTTPS yapılandırması

Ürün ve fiyatlar örnek/başlangıç amaçlıdır; mağaza yayına alınmadan önce gerçek ürünlerle doldurulmalıdır.
