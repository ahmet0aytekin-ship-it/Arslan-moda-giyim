require("dotenv").config();
const fs = require("fs");
const path = require("path");
const bcrypt = require("bcryptjs");
const dir = path.join(__dirname, "data");
fs.mkdirSync(dir, { recursive: true });
const username = process.env.ADMIN_USERNAME || "arslanmoda42";
const password = process.env.ADMIN_PASSWORD;
if (!password || password.length < 12) {
  console.error("ADMIN_PASSWORD .env içinde en az 12 karakter olmalı.");
  process.exit(1);
}
const output = path.join(dir, "admin.json");
fs.writeFileSync(output, JSON.stringify({ username, passwordHash: bcrypt.hashSync(password, 12) }, null, 2));
console.log(`Yönetici hesabı hazır: ${username}`);
console.log("Şifrenin kendisi dosyaya açık metin olarak kaydedilmedi.");
