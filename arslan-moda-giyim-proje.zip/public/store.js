let allProducts = [];
let phone = "905433134576";
const money = n => new Intl.NumberFormat("tr-TR", {style:"currency",currency:"TRY",maximumFractionDigits:2}).format(Number(n)||0);
const safe = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function waLink(p) {
  const msg = `Merhaba, Arslan Moda Giyim'den sipariş vermek istiyorum.%0AÜrün: ${encodeURIComponent(p.name)}%0AFiyat: ${encodeURIComponent(money(p.price))}%0ABeden: %0ARenk: %0AAd Soyad: %0AAdres: `;
  return `https://wa.me/${phone}?text=${msg}`;
}
function renderProducts(category = "") {
  const items = category ? allProducts.filter(p => p.category.toLocaleLowerCase("tr").includes(category.toLocaleLowerCase("tr"))) : allProducts;
  document.getElementById("filter-note").textContent = category ? `Kategori: ${category}` : "Koleksiyonun tamamı";
  const el = document.getElementById("products");
  if (!items.length) {
    el.innerHTML = `<div class="empty"><p>Bu kategoride henüz ürün yok.</p><p>Ürünlerini yönetim panelinden ekleyebilirsin.</p></div>`;
    return;
  }
  el.innerHTML = items.map(p => `<article class="product-card">
    <div class="product-image">${p.image ? `<img loading="lazy" src="${safe(p.image)}" alt="${safe(p.name)}" onerror="this.remove()">` : `<span class="placeholder-art">ARSLAN / MODA</span>`}</div>
    <div class="product-info"><div class="product-top"><h3>${safe(p.name)}</h3><span class="price">${money(p.price)}</span></div>
    <div class="description">${safe(p.description || p.category)}</div>
    <div class="pills">${(p.sizes||[]).map(s=>`<span class="pill">${safe(s)}</span>`).join("")}${(p.colors||[]).slice(0,3).map(c=>`<span class="pill">${safe(c)}</span>`).join("")}</div>
    <a class="order-btn" href="${waLink(p)}" target="_blank" rel="noopener">WHATSAPP'TAN SİPARİŞ VER ↗</a></div></article>`).join("");
}
document.querySelectorAll("[data-category]").forEach(a => a.addEventListener("click", () => renderProducts(a.dataset.category)));
async function init() {
  document.getElementById("year").textContent = new Date().getFullYear();
  try {
    const [p, c] = await Promise.all([fetch("/api/products"), fetch("/api/config")]);
    allProducts = await p.json();
    const config = await c.json();
    phone = config.whatsappPhone || phone;
    document.getElementById("general-wa").href = `https://wa.me/${phone}?text=${encodeURIComponent("Merhaba, Arslan Moda Giyim ürünleri hakkında bilgi almak istiyorum.")}`;
    renderProducts();
  } catch { document.getElementById("products").innerHTML = "<p>Ürünler yüklenemedi. Lütfen daha sonra tekrar deneyin.</p>"; }
}
init();
