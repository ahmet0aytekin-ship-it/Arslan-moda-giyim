const $ = s => document.querySelector(s);
const loginCard = $("#login-card"), dashboard = $("#dashboard"), form = $("#product-form");
let products = [];
async function request(url, options={}) {
  const res = await fetch(url, {headers:{"Content-Type":"application/json", ...(options.headers||{})}, ...options});
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || "İşlem tamamlanamadı.");
  return data;
}
function showDashboard(on) { loginCard.hidden=!on; dashboard.hidden=!on; }
async function checkSession() { try { const s=await request("/api/admin/session"); showDashboard(s.authenticated); if(s.authenticated) await loadProducts(); } catch {} }
$("#login-form").addEventListener("submit", async e=>{
  e.preventDefault(); $("#login-error").textContent="";
  const data=Object.fromEntries(new FormData(e.currentTarget));
  try { await request("/api/admin/login",{method:"POST",body:JSON.stringify(data)}); e.currentTarget.reset(); await checkSession(); }
  catch(err){$("#login-error").textContent=err.message;}
});
$("#logout").addEventListener("click",async()=>{await request("/api/admin/logout",{method:"POST"});showDashboard(false);});
async function loadProducts(){ products=await request("/api/products"); renderInventory(); }
function renderInventory(){
  const el=$("#inventory-list");
  if(!products.length){el.innerHTML='<p class="empty">Henüz ürün eklenmedi. İlk ürününü soldaki formdan ekleyebilirsin.</p>';return;}
  el.innerHTML=products.map(p=>`<div class="inventory-item"><div class="thumb">${p.image?`<img src="${esc(p.image)}" alt="">`:"ARSLAN"}</div><div class="item-details"><b>${esc(p.name)}</b><span>${esc(p.category)} · ${Number(p.price).toLocaleString("tr-TR")} TL</span><span>Stok: ${p.stock} · ${(p.sizes||[]).join(", ")}</span></div><div class="item-actions"><button data-edit="${p.id}" class="secondary">Düzenle</button><button data-delete="${p.id}" class="delete">Sil</button></div></div>`).join("");
  el.querySelectorAll("[data-edit]").forEach(b=>b.addEventListener("click",()=>editProduct(b.dataset.edit)));
  el.querySelectorAll("[data-delete]").forEach(b=>b.addEventListener("click",()=>deleteProduct(b.dataset.delete)));
}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function resetForm(){form.reset();form.elements.id.value="";$("#form-title").textContent="Yeni ürün ekle";$("#save-button").textContent="Ürünü kaydet";$("#cancel-edit").hidden=true;form.elements.sizes.value="S, M, L, XL, XXL";form.elements.colors.value="Siyah, Beyaz, Gri";form.elements.stock.value=0;$("#form-message").textContent="";}
function editProduct(id){const p=products.find(x=>x.id===id);if(!p)return;form.elements.id.value=p.id;form.elements.name.value=p.name;form.elements.category.value=p.category;form.elements.price.value=p.price;form.elements.stock.value=p.stock;form.elements.image.value=p.image||"";form.elements.description.value=p.description||"";form.elements.sizes.value=(p.sizes||[]).join(", ");form.elements.colors.value=(p.colors||[]).join(", ");$("#form-title").textContent="Ürünü düzenle";$("#save-button").textContent="Değişiklikleri kaydet";$("#cancel-edit").hidden=false;window.scrollTo({top:0,behavior:"smooth"});}
$("#cancel-edit").addEventListener("click",resetForm);
form.addEventListener("submit",async e=>{e.preventDefault();$("#form-message").textContent="Kaydediliyor…";const data=Object.fromEntries(new FormData(form));const id=data.id;delete data.id;try{await request(id?`/api/admin/products/${id}`:"/api/admin/products",{method:id?"PUT":"POST",body:JSON.stringify(data)});$("#form-message").textContent="Ürün kaydedildi.";resetForm();await loadProducts();}catch(err){$("#form-message").textContent=err.message;}});
async function deleteProduct(id){const p=products.find(x=>x.id===id);if(!p||!confirm(`“${p.name}” ürününü silmek istiyor musun?`))return;try{await request(`/api/admin/products/${id}`,{method:"DELETE"});await loadProducts();}catch(err){alert(err.message);}}
checkSession();
